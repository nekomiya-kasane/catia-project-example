#pragma once

inline void protected_2_1() {
  return;
}

void protected_2_1_5();