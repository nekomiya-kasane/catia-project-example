#pragma once

inline void private_2_1() {
  return;
}