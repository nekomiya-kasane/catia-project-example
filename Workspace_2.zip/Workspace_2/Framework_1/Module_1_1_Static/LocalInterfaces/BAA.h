#pragma once

void func_2_1_1_static ();

inline void func_2_1_1_static_inline () {
    return;
}