#pragma once

#include "module-2-1-6-dynamic-protected_export.h"

#include "fmt/color.h"

void MODULE_2_1_6_DYNAMIC_PROTECTED_EXPORT func_2_1_6_dynamic_protected();

inline void func_2_1_6_dynamic_protected_inline() {
    return;
}