#include "BAF.h"

#include "public_2_1.h"
#include "protected_2_1.h"
#include "private_2_1.h"

void func_2_1_6_dynamic_protected() {
	public_2_1();
	protected_2_1();
	private_2_1();
	return;
}