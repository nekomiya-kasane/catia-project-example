#pragma once

#include "fmt/color.h"

void func_2_1_5_static_protected();

inline void func_2_1_5_static_protected_inline() {
    return;
}