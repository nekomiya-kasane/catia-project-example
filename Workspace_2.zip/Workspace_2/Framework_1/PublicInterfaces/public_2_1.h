#pragma once

inline void public_2_1() {
  return;
}