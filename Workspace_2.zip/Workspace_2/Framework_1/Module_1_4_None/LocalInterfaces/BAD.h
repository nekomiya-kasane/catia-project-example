#pragma once

#include "module-2-1-4-dynamic_export.h"

void MODULE_2_1_4_DYNAMIC_EXPORT func_2_1_4_none();

inline void func_2_1_4_none_inline() {
    return;
}