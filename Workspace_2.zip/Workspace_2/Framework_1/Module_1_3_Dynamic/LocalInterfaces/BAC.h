#pragma once

#include "module-2-1-3-dynamic_export.h"

void MODULE_2_1_3_DYNAMIC_EXPORT func_2_1_3_Dynamic();

inline void func_2_1_3_Dynamic_inline() {
    return;
}