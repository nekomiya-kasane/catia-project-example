#pragma once

#include "module-2-1-4-dynamic_export.h"

void func_2_1_2_none();

inline void func_2_1_2_none_inline() {
    return;
}