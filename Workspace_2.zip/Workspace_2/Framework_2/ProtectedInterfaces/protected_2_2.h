#pragma once

inline void protected_2_2() {
  return;
}