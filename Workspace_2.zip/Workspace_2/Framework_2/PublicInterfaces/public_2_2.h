#pragma once

inline void public_2_2() {
  return;
}