#pragma once

void func_2_2_1_static ();

inline void func_2_2_1_static_inline () {
    return;
}