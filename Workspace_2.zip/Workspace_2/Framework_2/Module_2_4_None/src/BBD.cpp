#include "BBD.h"

#include "public_2_2.h"
#include "protected_2_2.h"
#include "private_2_2.h"

void func_2_2_4_none() {
	public_2_2();
	protected_2_2();
	private_2_2();
	return;
}