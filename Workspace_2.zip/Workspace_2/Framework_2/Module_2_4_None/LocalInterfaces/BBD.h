#pragma once

#include "module-2-2-4-dynamic_export.h"

void MODULE_2_2_4_DYNAMIC_EXPORT func_2_2_4_none();

inline void func_2_2_4_none_inline() {
    return;
}