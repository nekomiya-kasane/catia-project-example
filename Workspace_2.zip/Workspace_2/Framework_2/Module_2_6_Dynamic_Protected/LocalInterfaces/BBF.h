#pragma once

#include "module-2-2-6-dynamic-protected_export.h"

#include "fmt/color.h"

void MODULE_2_2_6_DYNAMIC_PROTECTED_EXPORT func_2_2_6_dynamic_protected();

inline void func_2_2_6_dynamic_protected_inline() {
    return;
}