#pragma once

#include "fmt/color.h"

void func_2_2_5_static_protected();

inline void func_2_2_5_static_protected_inline() {
    return;
}