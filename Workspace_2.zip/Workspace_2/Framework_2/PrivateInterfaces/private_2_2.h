#pragma once

inline void private_2_2() {
  return;
}